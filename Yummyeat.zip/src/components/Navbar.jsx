import { Link } from 'react-router-dom'
import { Sun, Moon, ShoppingBag } from 'lucide-react'
import { useApp } from '../AppContext'

export default function Navbar({ onOpenCart }) {
  const { t, lang, setLang, theme, setTheme, cartCount } = useApp()

  return (
    <header className="shrink-0 z-20 bg-app/80 backdrop-blur-xl border-b border-line pt-[env(safe-area-inset-top)]" style={{ backgroundColor: 'rgb(var(--color-bg) / 0.85)' }}>
      <div className="max-w-7xl mx-auto w-full px-4 md:px-8 h-16 flex items-center gap-3">
        <Link to="/" className="flex items-center gap-2.5 shrink-0">
          <div className="w-10 h-10 rounded-2xl bg-primary grid place-items-center neon-box">
            <span className="font-brand text-white text-lg leading-none">Y</span>
          </div>
          <div className="leading-none" dir="ltr">
            <div className="font-brand text-lg neon-text flicker">YUMMY</div>
            <div className="font-brand text-[11px] tracking-[0.35em] neon-yellow">EAT</div>
          </div>
        </Link>

        <div className="flex items-center gap-1.5 ms-auto">
          <button
            onClick={() => setLang(lang === 'fr' ? 'ar' : 'fr')}
            className="h-10 px-1 rounded-full bg-card-2 border border-line flex items-center text-xs font-extrabold"
            aria-label="Language"
          >
            <span className={`px-2.5 py-1.5 rounded-full transition-colors ${lang === 'fr' ? 'bg-primary text-white' : 'text-muted'}`}>FR</span>
            <span className={`px-2.5 py-1.5 rounded-full transition-colors ${lang === 'ar' ? 'bg-primary text-white' : 'text-muted'}`}>ع</span>
          </button>
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="w-10 h-10 rounded-full bg-card-2 border border-line grid place-items-center hover:border-primary transition-colors"
            aria-label="Theme"
          >
            {theme === 'dark' ? <Sun className="w-5 h-5 text-secondary" /> : <Moon className="w-5 h-5 text-primary" />}
          </button>
          <button
            onClick={onOpenCart}
            className="relative w-10 h-10 rounded-full bg-primary text-white grid place-items-center hover:brightness-110 transition"
            aria-label={t('cart')}
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span key={cartCount} className="pop absolute -top-1 -end-1 min-w-[20px] h-5 px-1 rounded-full bg-secondary text-[#2a0a3d] text-[11px] font-extrabold grid place-items-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

    </header>
  )
}
